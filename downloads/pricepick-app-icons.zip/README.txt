PricePick 앱 아이콘 PNG 세트
=============================
브랜드 보라(#845EEE) 불투명 배경 + 흰색 P 심볼. 알파 채널 없음(iOS 앱스토어 호환).
라운드 코너는 OS가 자동 마스킹하므로 풀블리드 정사각으로 제공합니다.

파일 / 사이즈 / 용도
- pricepick-icon-1024.png  1024x1024  iOS 앱스토어 제출용(App Store / Marketing)
- pricepick-icon-512.png    512x512   Google Play / PWA manifest 대표 아이콘
- pricepick-icon-192.png    192x192   Android / PWA manifest(홈 화면)
- pricepick-icon-180.png    180x180   apple-touch-icon (iPhone @3x)
- pricepick-icon-167.png    167x167   apple-touch-icon (iPad Pro)
- pricepick-icon-152.png    152x152   apple-touch-icon (iPad @2x)
- pricepick-icon-120.png    120x120   apple-touch-icon (iPhone @2x)
- pricepick-icon-96.png      96x96    Android / 파비콘 대형
- pricepick-icon-72.png      72x72    Android mdpi
- pricepick-icon-48.png      48x48    파비콘 / 소형 런처

원본: PricePick 브랜드 심볼 SVG(Symbol_OnDark) → 보라 배경 합성 후 래스터화.
